/************** LOCALIZABLE GLOBAL VARIABLES ****************/

var MSG_EvenArgs = 'The %s function requires an even number of arguments.'
                 + '\nArguments should be in the form "atttributeName","attributeValue",...';
var MSG_SrcRequired = "The %s function requires that a movie src be passed in as one of the arguments.";

/******************** END LOCALIZABLE **********************/

// Finds a parameter with the name paramName, and checks to see if it has the 
// passed extension. If it doesn't have it, this function adds the extension.
function AC_AddExtension(args, paramName, extension)
{
  var currArg, paramVal, queryStr, endStr;
  for (var i=0; i < args.length; i=i+2){
    currArg = args[i].toLowerCase();    
    if (currArg == paramName.toLowerCase() && args.length > i+1) {
      paramVal = args[i+1];
      queryStr = "";

      // Pull off the query string if it exists.
      var indQueryStr = args[i+1].indexOf('?');
      if (indQueryStr != -1){
        paramVal = args[i+1].substring(0, indQueryStr);
        queryStr = args[i+1].substr(indQueryStr);
      }

      endStr = "";
      if (paramVal.length > extension.length)
        endStr = paramVal.substr(paramVal.length - extension.length);
      if (endStr.toLowerCase() != extension.toLowerCase()) {
        // Extension doesn't exist, add it
        args[i+1] = paramVal + extension + queryStr;
      }
    }
  }
}

// Substitutes values for %s in a string. Usage: AC_sprintf("The %s function
// requires %s arguments.", "foo()", "4");
function AC_sprintf(str){
  for (var i=1; i < arguments.length; i++){
    str = str.replace(/%s/,arguments[i]);
  }
  return str;
}
		
// Checks that args, the argument list to check, has an even number of arguments.
// Alerts the user if an odd number of arguments is found.
function AC_checkArgs(args,callingFn){
  var retVal = true;
  // If number of arguments isn't even, show a warning and return false.
  if (parseFloat(args.length/2) != parseInt(args.length/2)){
    alert(sprintf(MSG_EvenArgs,callingFn));
    retVal = false;
  }
  return retVal;
}
	
// This is a generic function used to generate object/embed/param tags. It is
// used by higher level api functions.
function AC_GenerateObj(callingFn, useXHTML, classid, pluginsPage, mimeType, args){

  if (!AC_checkArgs(args,callingFn)){
    return;
  }

  // Initialize variables
  var tagStr = '';
  var currArg = '';
  var closer = (useXHTML) ? '/>' : '>';
  var srcFound = false;
  var embedStr = '<embed';
  var paramStr = '';
  var embedNameAttr = '';
  var objStr = '<object classid="' + classid + '"';

  // Spin through all the argument pairs, assigning attributes and values to the object, param, and embed tags as appropriate.
  for (var i = 0; i < args.length; i = i + 2) {
    currArg = args[i].toLowerCase();    

    if (currArg == "src") {
      paramStr += '<param name="' + args[i] + '" value="' + args[i + 1] + '"' + closer + '\n'; 
      embedStr += ' ' + args[i] + '="' + args[i + 1] + '"';
      srcFound = true;
    }
    else if ( currArg == "width" 
           || currArg == "height" 
           || currArg == "align" 
           || currArg == "vspace" 
           || currArg == "hspace" 
           || currArg == "class" 
           || currArg == "title" 
           || currArg == "accesskey" 
           || currArg == "tabindex") {
      objStr += ' ' + args[i] + '="' + args[i + 1] + '"';
      embedStr += ' ' + args[i] + '="' + args[i + 1] + '"';
    }
    else if (currArg == "id") {
      objStr += ' ' + args[i] + '="' + args[i + 1] + '"';
      // Only add the name attribute to the embed tag if a name attribute isn't already there.
      if (embedNameAttr == "")
        embedNameAttr = ' name="' + args[i + 1] + '"';
    }
    else if (currArg == "name") {
      objStr += ' ' + args[i] + '="' + args[i + 1] + '"';
      // Replace the current embed tag name attribute with the one passed in.
      embedNameAttr = ' ' + args[i] + '="' + args[i + 1] + '"';
    }    
    else if (currArg == "codebase") {
      objStr += ' ' + args[i] + '="' + args[i + 1] + '"';
    }
    // This is an attribute we don't know about. Assume that we should add it to the param and embed strings.
    else {
      paramStr += '<param name="' + args[i] + '" value="' + args[i + 1] + '"' + closer + '\n'; 
      embedStr += ' ' + args[i] + '="' + args[i + 1] + '"';
    }
  }

  // Tell the user that a src is required, if one was not passed in.
  if (!srcFound) {
    alert(AC_sprintf(MSG_SrcRequired, callingFn));
    return;
  }

  if (embedNameAttr)
    embedStr += embedNameAttr;	
  if (pluginsPage)
    embedStr += ' pluginspage="' + pluginsPage + '"';
  if (mimeType)
    embedStr += ' type="' + mimeType + '"';
    
  // Close off the object and embed strings.
  objStr += '>\n';
  embedStr += '></embed>\n'; 

  // Assemble the three tag strings into a single string.
  tagStr = objStr + paramStr + embedStr + "</object>\n";

  document.write(tagStr);
}

// The code below contains functions that run active content. The functions
// assemble an OBJECT/EMBED tag string, and then perform a document.write of 
// this string in the calling html document.
//   AC_RunAuthorware()  - build tags to display Authorware content.
//   AC_RunAuthorwareX() - build XHTML formatted tags to display Authorware content.
//
// To call one of these functions, pass all the attributes and values that you would 
// otherwise specify for the object, param, and embed tags in the following form:
//   AC_RunAuthorware(
//     "attrName1", "attrValue1"
//     "attrName2", "attrValue2"
//     ...
//     "attrName[n]", "attrValue[n]"
//   )
//
// When passing in the src attribute, do not include the file extension. Note, these
// functions use default values for several standard tag attributes, including classid,
// pluginsPage, and mimeType, depending on the function you call. So, you should not
// pass in values for these attributes. If you require an alternate value for these
// attributes, you'll need to modify the default values used in the 'Run' function
// implementations below.

function AC_RunAuthorware() {
  // First, look for a "src" param, and if available, add a ".aam" to the end
  // if it doesn't already have one (this function will only run aam files)
  AC_AddExtension(arguments, "src", ".aam");

	AC_GenerateObj("AC_RunAuthorware()", false, "clsid:15b782af-55d8-11d1-b477-006097098764", 
  "http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveAuthorware",
  "application/x-authorware-map", arguments);
}

function AC_RunAuthorwareX() {
  // First, look for a "src" param, and if available, add a ".aam" to the end
  // if it doesn't already have one (this function will only run aam files)
  AC_AddExtension(arguments, "src", ".aam");

	AC_GenerateObj("AC_RunAuthorwareX()", true, "clsid:15b782af-55d8-11d1-b477-006097098764",
  "http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveAuthorware",
  "application/x-authorware-map", arguments);	
}